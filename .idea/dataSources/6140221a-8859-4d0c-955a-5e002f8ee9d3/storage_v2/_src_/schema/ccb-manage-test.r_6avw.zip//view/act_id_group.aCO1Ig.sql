create view act_id_group as
  select
    `r`.`rolecode`  AS `id_`,
    1               AS `rev_`,
    `r`.`rolename`  AS `name_`,
    `r`.`role_type` AS `type_`
  from `ccb-manage-test`.`t_s_role` `r`;

