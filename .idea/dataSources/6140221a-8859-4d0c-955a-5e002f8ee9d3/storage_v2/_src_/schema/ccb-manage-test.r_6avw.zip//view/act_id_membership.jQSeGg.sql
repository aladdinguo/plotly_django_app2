create view act_id_membership as
  select
    `bu`.`username` AS `user_id_`,
    `r`.`rolecode`  AS `group_id_`
  from ((`ccb-manage-test`.`t_s_role_user` `ru` left join `ccb-manage-test`.`t_s_base_user` `bu`
      on ((`ru`.`userid` = `bu`.`ID`))) left join `ccb-manage-test`.`t_s_role` `r` on ((`ru`.`roleid` = `r`.`ID`)));

