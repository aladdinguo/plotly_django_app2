create view act_id_user as
  select
    `u`.`username` AS `id_`,
    1              AS `rev_`,
    `u`.`realname` AS `first_`,
    NULL           AS `last_`,
    NULL           AS `email_`,
    `u`.`password` AS `pwd_`,
    NULL           AS `picture_id_`
  from `ccb-manage-test`.`t_s_base_user` `u`;

